package com.bootcoding.java.OOPS.Inheritance.Cycle;

public class GearCycle extends Cycle{
    public void gear() {
    }
}
