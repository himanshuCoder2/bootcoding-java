package com.bootcoding.java.OOPS.Inheritance.Cycle;

public class Gear extends  Cycle{
}
