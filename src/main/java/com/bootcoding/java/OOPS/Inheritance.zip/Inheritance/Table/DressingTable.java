package com.bootcoding.java.OOPS.Inheritance.Table;

public class DressingTable {
}
