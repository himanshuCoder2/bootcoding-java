package com.bootcoding.java.OOPS.Inheritance.Table;

import com.bootcoding.java.OOPS.Inheritance.Table.Table;

public class DinningTable extends Table {
}
