package com.bootcoding.java.OOPS.Inheritance.Cycle;

public class SportCycle extends Cycle{
}
